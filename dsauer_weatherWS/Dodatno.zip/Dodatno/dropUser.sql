<sql delimiter="#GO" delimitertype="row" keepformat="true" driver="${db.driver}" url="${db.url.admin}" userid="${db.user.admin}" password="${db.pass.admin}" classpath="${driver.mysql}" >
            USE ${db.name};
            DROP PROCEDURE IF EXISTS ${db.name}.create_user_if_exists;

            CREATE PROCEDURE ${db.name}.create_user_if_exists()
            BEGIN
              DECLARE broj BIGINT DEFAULT -1;
              SELECT COUNT(*) INTO broj FROM mysql.user WHERE User = '${db.user}' and  Host = '${host}';
               IF broj = 0 THEN
                     CREATE USER IF NOT EXISTS ${db.user}@${host} IDENTIFIED BY '${db.pass}';
                     GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,DROP ON `${db.name}`.* TO `${db.user}`@`${host}` IDENTIFIED BY '${db.pass}';
              END IF;
            END; #GO
            
            CALL ${db.name}.create_user_if_exists();
            DROP PROCEDURE IF EXISTS ${db.name}.create_users_if_exists;
            
            
        </sql>   